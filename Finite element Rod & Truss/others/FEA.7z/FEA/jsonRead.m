clear
clc

fname = 'dielectric_boundary_data3.json';
fid = fopen(fname);
raw = fread(fid,inf);
str = char(raw');
fclose(fid);
data = JSON.parse(str)