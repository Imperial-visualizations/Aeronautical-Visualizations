clear 
kmax=10; 
imax=2*kmax+2; 
L=1; l1=L/kmax; 
ey=2.1e11; 
b=0.01; 
h=0.1; 
A=b*h; 
jp=h*h*h*b/12; 
ro=7800;

xbar= [1.875104068706770e+000 ... 
    4.694091132933031e+000 ... 
    7.854757438070675e+000 ... 
    1.099554073487850e+001 ... 
    1.413716839104652e+001 ... 
    1.727875953327674e+001 ... 
    2.042035225104147e+001 ... 
    2.356194490180130e+001 ... 
    2.670353755550106e+001 ... 
    2.984513020909291e+001 ... 
    3.298672286269287e+001 ... 
    3.612831551628358e+001 ... 
    3.926990818348858e+001 ... 
    4.241150082346221e+001 ... 
    4.555309347705200e+001 ... 
    4.869468613064180e+001 ... 
    5.183627878423159e+001 ... 
    5.497787143782138e+001 ... 
    5.811946409141117e+001 ... 
    6.126105674500097e+001 ... 
    6.440264939859077e+001 ... 
    6.754424205218055e+001 ]; 
c0=sqrt(ey/ro); 
j=sqrt(jp/A); 
b2=xbar.*xbar; 
om=b2*c0*j/(L^2); 
[xke]=VBErigbeam(ey,l1,jp); 
[xme]=VBEmasbeam(ro,l1,A); 
[xk,xm]=VBEglobeam(kmax,imax,xke,xme); 
bound = [imax-1 imax]; 
xk(bound,:)=[]; 
xk(:,bound)=[]; 
xm(bound,:)=[]; 
xm(:,bound)=[]; 
ei=eig(xk,xm); 
ef=sort(real(sqrt(ei))); 
f=ef/(2*pi); 
ix=1:20; 
figure(1) 
subplot(1,2,1) 
plot(ix,ef(ix),'ro', ix,om(ix),'kx','markersize',8); 
title(' o - FEM, x - analytical'); 
xlabel('counter'); 
ylabel('angular frequencies'); 
ix = 1:9; r=zeros(size(ix)); 
for i=ix 
    r(i)=100*(ef(i)-om(i))/om(i); 
end
subplot(1,2,2)
plot(ix,r,'ko','markersize',8); 
title('relative errors for FE frequencies ')
xlabel('counter'); 
print VBEbefre2 -deps; 
print VBEbefre2 -dmeta; 
format long e 
delete befre2.dat 
diary befre2.dat 
disp(' counter, analytical frequencies, FE frequencies') 
disp([ix' om(ix)' ef(ix)]) 
diary off 
format short e