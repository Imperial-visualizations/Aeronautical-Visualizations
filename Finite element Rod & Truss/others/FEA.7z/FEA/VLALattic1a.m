clear
clc
close all;
ncast=30; 
m=1.2; 
k=1e3; 
om0=sqrt(k/m);

kstar=zeros(ncast,ncast); 
for i=1:ncast 
    kstar(i,i)=2; 
end
kstar(1,1)=1;
kstar(ncast,ncast)=1; 
for i=2:ncast 
    kstar(i,i-1)=-1; 
end
for i=1:ncast-1 
    kstar(i,i+1)=-1; 
end

[v,ei]=eig(kstar);

eid=abs(real(diag(ei)));
[eis,ii]=sort(eid); 
angfr=sqrt(eis)*om0;

for i=1:ncast 
    vs(:,i)=v(:,ii(i)); 
end

figure(1) 
for i=1:ncast subplot(6,6,i) 
    plot(vs(:,i),'k'); 
    title(num2str(angfr(i))) 
    axis('off') 
end
print VLAlatf1 -deps; 
print VLAlatf1 -dmeta;

figure(2) 
plot(vs(:,ncast),'k'); 
title(num2str(angfr(ncast))); 
print VLAlatf2 -deps; 
print VLAlatf2 -dmeta;

figure(3) 
lab1=['angular eigenfrequencies']; 
plot(angfr,'kx', 'linewidth', 2); 
title(lab1); xlabel('counter') 
print VLAlatf3 -deps; 
print VLAlatf3 -dmeta;