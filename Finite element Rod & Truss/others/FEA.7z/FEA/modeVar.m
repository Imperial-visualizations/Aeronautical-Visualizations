clear; clc; close all;

for kmax = 1:24
    imax=kmax+1;
    % icons = input('consistent or diagonal? enter (1 or 0) ... ');
    icons = 1; % 1 for consistent, 0 for diagonal
    xmec=[2 1; 1 2]; % consistent mass matrix
    xmed=[3 0; 0 3]; % diagonal mass matrix
    
    if icons == 1
        label = ['consistent mass'];
        xme = xmec;
    else
        label = ['diagonal mass'];
        xme = xmed;
    end
    
    xke=[1 -1; -1 1];
    
    loclam=eig(xke,xme);
%     disp([loclam sqrt(6*real(loclam))]);
    xm=zeros(imax);
    xk=zeros(imax);
    for k=1:kmax
        ic(1) = k;
        ic(2) = k + 1;
        xm(ic,ic) = xm(ic,ic) + xme;
        xk(ic,ic) = xk(ic,ic) + xke;
    end
    
    [ve ei] = eig(xk,xm);
    omstar=sqrt(6*(diag(ei)));
    omstar=real(omstar);
    [omstarsort,ii]=sort(omstar);
    omstarsort(1)=0;
    
    for i=2:kmax+1
        ckstar(i)=omstarsort(i)*kmax/((i-1)*pi);
    end;
    
    ckstar(1)=1;
    A.(sprintf('ModeShape_%d', kmax)) = ve';
end

data = jsonencode(A);