function [kglobal,mglobal]=VTSglobv(d,kmax,imax,alf,ro,l,a,ey,icons)
kglobal = zeros(imax,imax); 
mglobal = zeros(imax,imax); 
for k=1:kmax 
    kelem = ... 
        get element stiffness matrix of k-th element 
    melem = ... 
        get element mass matrix of k-th element 
    c = ... 
        get code numbers of the k-th element 
    kglobal(c,c) = kglobal(c,c) + kelem; 
    mglobal(c,c) = mglobal(c,c) + melem; 
end;

