function xke=VTSrigbarv(ey,l,a,alf)
% local stiffness matrix of a truss element
% with 4 dof�s
% ey ... Young modulus
% l .... length of element
% a .... cross sectional area
% alf .. an oriented angle between x-axis and truss (in radians)
konst=ey*a/l;
kbar4 = [1 0 -1 0; 0 0 0 0; -1 0 1 0; 0 0 0 0];
c = cos(alf); s = sin(alf);
t = [c s 0 0; -s c 0 0; 0 0 c s; 0 0 -s c];
xke = konst*t'*kbar4*t;
% this is an alternative way how to do it
% c=cos(alf); s=sin(alf);
% k=[1 -1; -1 1];
% t=[c s 0 0 ; 0 0 c s];
% xke=konst*t�*k*t;
% end of VTSrigbarv