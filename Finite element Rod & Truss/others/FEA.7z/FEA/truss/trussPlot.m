clear; clc; close all; 
format short; format compact

% x = [10 15 15 20 20 25];
% y = [0 7.5 0 7.5 0 0];

x = [0 5 10 15 10 10 5 10 5 5 0];
y = [0 7.5 7.5 0 0 7.5 0 0 7.5 0 0];
1 2 4 6 5 4 3 5 2 3 1

figure(1)
plot(x,y,'o',x,y); axis([0,35,0,35]); axis('equal')