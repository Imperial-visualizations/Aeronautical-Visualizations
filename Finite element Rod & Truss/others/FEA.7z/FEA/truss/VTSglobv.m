function [kglobal,mglobal]=VTSglobv(d,kmax,imax,alf,ro,l,a,ey,icons)
% assemble global stiffness and mass matrices
% imax is the global number of degrees of freedom (structure)
% kmax is number of elements
% lmax is number local degrees of freedom of an element
% zeroing of arrays
kglobal = zeros(imax,imax);
mglobal = zeros(imax,imax);
for k=1:kmax % loop over all the elements
    kelem = VTSrigbarv(ey,l(k),a(k),alf(k));
    % get element stiffness matrix of k-th element
    melem = VTSmasbarv(ro,l(k),a(k),alf(k),icons)
    % get element mass matrix of k-th element
    c = d(k,:) 
    % get code numbers of the k-th element
    %size of c is(1,lmax)
    kglobal(c,c) = kglobal(c,c) + kelem;
    mglobal(c,c) = mglobal(c,c) + melem;
    % note: size of kelem and melem is (lmax,lmax)
end;

