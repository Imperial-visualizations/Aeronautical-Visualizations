clear; clc; close all;
format compact 
syms t tt c s 
t = [c s 0 0; -s c 0 0; 0 0 c s; 0 0 -s c]; 
tt= [c -s 0 0; s c 0 0; 0 0 c -s; 0 0 s c]; 
kb = [1 0 -1 0; 0 0 0 0; -1 0 1 0; 0 0 0 0]; 
mcb = [2 0 1 0; 0 2 0 1; 1 0 2 0; 0 1 0 2];	
mdb = [3 0 0 0; 0 3 0 0; 0 0 3 0; 0 0 0 3]; 
disp('multiplicative constants are left out') 
disp('stiffness matrix') 
k = tt*kb*t 
mc = tt*mcb*t; 
mc1=subs(mc,2*c^2+2*s^2,2); 
disp('consistent mass matrix - independent of coordinate ... transformation') 
subs(mc1,c^2+s^2,1) 
md = tt*mdb*t; 
disp('diagonal mass matrix - independent of coordinate ... transformation') 
subs(md,3*c^2+3*s^2,3)

