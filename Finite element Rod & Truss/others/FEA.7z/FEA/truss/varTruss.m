clear
clc
close all

imax = 20;

for index = 1:imax
    force3 = 1e6/imax*index;
    coord = deformed(force3);
    shape.(sprintf('deformedCoord_%d', index)) = coord;
end