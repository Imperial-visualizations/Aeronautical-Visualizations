function xme=VTSmasbarv(ro,l,a,alf,icons)
% xme mass matrix of a 2d truss element
% ro density
% l length of truss
% alf angle measured from global x to truss centreline
% icons mass matrix formulation switch
% = 1 ... consistent
% = 0 ... diagonal
if icons == 1,
m = [2 0 1 0; 0 2 0 1; 1 0 2 0; 0 1 0 2];
else
m = [3 0 0 0; 0 3 0 0; 0 0 3 0; 0 0 0 3];
end
konst=ro*l*a/6;
% c=cos(alf); s=sin(alf);
% t=[c s 0 0; -s c 0 0; 0 0 c s; 0 0 -s c];
% xme=konst*t�*m*t;
xme = konst*m;
% there is no need to carry out the coordinate transformation
% since the mass matrix is insensitive to it
% end of VTSmasbarv