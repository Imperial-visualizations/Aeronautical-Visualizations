% kmax .......... number of elements
% input values
clear; clc; close all; 
d=clock; disp([d(3) d(2) d(1) d(4) d(5)])
format short; format compact
% input data
kmax=15; % number of elements
imax=16; % number of generalized d.o.f.
imaxb=4; % number of prescribed zero bound. displ.
imaxc=imax-imaxb; % number of condensed d.o.f.
% nodal coordinates
x=[10 10 10 10 15 15 15 15];
% x = [10 15 20 25 20 15 15 20 20 15 10];
y=[0 7.5 15 22.5 22.5 15 7.5 0];
% y = [0 7.5 7.5 0 0 0 7.5 0 7.5 0 0];
% pointers to x-displacements at nodes
xp=[13 9 5 1 3 7 11 15];
% xp = [1 3 5 7 9 11 3 9 5 11 1];
% pointers to y-displacements at nodes
yp=[14 10 6 2 4 8 12 16];
% yp = [2 4 6 8 10 12 4 10 6 12 2];
% plot outline of mesh
figure(1)
plot(x,y,'o',x,y); axis([0,35,0,35]); axis('equal')
% code numbers of all the elements
d=[ 1 2 3 4; 1 2 5 6; 1 2 7 8; 5 6 3 4; ...
    3 4 7 8; 5 6 7 8; 5 6 9 10; 5 6 11 12; ...
    9 10 7 8; 7 8 11 12; 9 10 11 12; 9 10 13 14; ...
    9 10 15 16; 13 14 11 12; 11 12 15 16];
% d = [ 1 2 3 4; 1 2 5 6; 3 4 5 6; 3 4 7 8; ...
%       3 4 9 10; 5 6 7 8; 5 6 9 10; 7 8 9 10; ...
%       7 8 11 12; 9 10 11 12];
% bound. conditions - pointers to prescribed zero displacements
bound=[13 14 15 16];
% bound = [1 2 11 12];
% lengths of elements in [m]
l=[5 7.5 9.01 9.01 7.5 5 7.5 9.01 9.01 7.5 5 7.5 9.01 9.01 7.5];
% l = [9.01 5 7.5 5 9.01 9.01 5 7.5 9.01 5];
% cross sections of elements in [m^2]
a=[6 8 4 4 8 6 8 4 4 8 6 8 4 4 8]*1e-5;
% a = [4 6 8 6 4 4 6 8 4 6]*1e-5;
% orientation of trusses with respect of x-axis
% by angles in radians
b1=pi/2; b2=atan(l(2)/l(1));
alf=[0 -b1 -b2 b2 -b1 0 -b1 -b2 b2 -b1 0 -b1 -b2 b2 -b1];
% alf = [b2 0 -b1 0 -b2 b2 0 -b1 -b2 0];
% Young modulus in [N/m^2]
ey=7.17e10;
% density in [kg/m^3];
ro=2768;
% assemble stiffness and mass matrices
% and choose mass matrix formulation

icons = ...
input('1 = consistent, 0 = diagonal, enter 1 or 0 ... ');
if icons == 1,
masslabel = ['consistent mass matrix']; disp(masslabel);
else
masslabel = ['diagonal mass matrix']; disp(masslabel);
end

% icons = 1;

[xk,xm]=VTSglobv(d,kmax,imax,alf,ro,l,a,ey,icons);
% make copies
xkcopy=xk; xmcopy=xm;
% calculate eigenvalues for unconstrained global matrices
l2=eig(xk,xm); r2k=rank(xk); r2m=rank(xm);
disp(' ')
disp('size of full (unconstrained) matrices')
size_xk = size(xk), size_xm = size(xm)
disp(' ')
disp('rank of unconstrained stiffness and mass matrices')
disp([r2k r2m]);
disp('eigenvalues for unconstrained global matrices')
disp(sort(real(l2')));
% taking the prescribed boundary conditions into account
% by deleting rows and columns corresponding to zero dof's
% this process is sometimes called condensing matrices
xk(bound,:)=[]; xm(bound,:)=[];
xk(:,bound)=[]; xm(:,bound)=[];
l=eig(xk,xm);
disp(' ')
disp('size of condensed matrices')
size_xk_cond = size(xk), size_xm_cond = size(xm)
disp(' ')
disp('rank of condensed stiffness and mass matrices')
rk=rank(xk); rm=rank(xm); disp([rk rm])
disp('eigenvalues by condensed matrices')
disp(sort(l'))
% there is another way how to do it, i.e.
% penalty approach - just for checking purposes
% instead of deleting rows and columns large numbers
% are put into corresponding diagonal positions
for i=1:4
xkcopy(bound(i),bound(i))=1e10;
xmcopy(bound(i),bound(i))=1e10;
end
l1=eig(xkcopy,xmcopy); r1k=rank(xk); r1m=rank(xm);
disp(' ')
disp('size of penalty treated matrices')
size_xk_penalty = size(xkcopy), size_xm_penalty = size(xmcopy)
disp(' ')
disp('rank of stiffness and mass matrices - penalty');
disp([r1k r1m])
disp('eigenvalues by penalty approach');
disp(sort(l1'))
format long e
l=sort(eig(xk,xm)); om=sqrt(l); f=om/(2*pi);
disp('sorted eigenvalues, angular frequencies and frequencies')
[l om f]
[v ll]=eig(xk,xm);
[sorted_eigenvalues,order] = sort(diag(ll));
sorted_ang_frequencies = sqrt(sorted_eigenvalues);
sorted_freq_in_Hz = sorted_ang_frequencies/(2*pi);
figure(2)
% plot all eigenvectors
coefx=2; coefy=2;
for i=1:imaxc
subplot(5,ceil(imax/5),i)
dd=v(:,order(i));
ddf=[dd' 0 0 0 0];
ddx=ddf(xp); ddy=ddf(yp);
xdef=x+coefx*ddx; ydef=y+coefy*ddy;
plot(x,y,'o', x,y, xdef,ydef,'x', xdef,ydef,'r');
axis('equal');
title(num2str(sorted_freq_in_Hz(i))); axis off
end
text(1,-5,masslabel);
string_icons = int2str(icons);
file_name = ['VTSstozar33w' string_icons];
print('-dmeta', file_name)
print('-deps', file_name)
% end of VTSstozar33w